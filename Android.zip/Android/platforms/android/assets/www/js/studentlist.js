var db;
var dbCreated = false;

var scroll = new iScroll('wrapper', { vScrollbar: false, hScrollbar:false, hScroll: false });
// onDeviceReady();
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
				 document.addEventListener("backbutton", function(){}, false);
// window.addEventListener("orientationchange", function(){
  // window.screen.lockOrientation('portrait-primary');
  });
  
     db = window.openDatabase("StudentDirectoryDB", "1.0", "test", 200000);
    db.transaction(getStudents, transaction_error);
}

function transaction_error(tx, error) {
	$('#busy').hide();
    alert("Database Error: " + error);
}

function getStudents(tx) {
	var sql = "select * " + 
				"from student_detail order by NAME";
	tx.executeSql(sql, [], getStudents_success);
}

function getStudents_success(tx, results) {

    var len = results.rows.length;
 for (var i=0; i<len; i++) {
    	var student = results.rows.item(i);
		
		$('#studentlist').append('<li><a href="studentdetails.html?id=' + student.id + '">' +
				'<img src="pics/student1.jpg" class="list-icon"/>' +
				'<p class="line1">' + student.NAME + ' (' + student.REGNO + ')</p>' +
				'<p class="line2">Dept:' + student.DEPARTMENT + ' Year:' + student.YEAR +'</p>' +
				'</a></li>');
    }
	setTimeout(function(){
		scroll.refresh();
	},100);
	db = null;
}

