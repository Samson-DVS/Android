var scroll = new iScroll('wrapper', { vScrollbar: false, hScrollbar:false, hScroll: false });

var id = getUrlVars()["id"];

var db;

document.addEventListener("deviceready", onDeviceReady, false);
// onDeviceReady();
function onDeviceReady() {
				 document.addEventListener("backbutton", function(){}, false);
// window.addEventListener("orientationchange", function(){
  // window.screen.lockOrientation('portrait-primary');
  });
    db = window.openDatabase("StudentDirectoryDB", "1.0", "test", 200000);
    db.transaction(getStudent, transaction_error);
}

function transaction_error(tx, error) {
	$('#busy').hide();
    alert("Database Error: " + error);
}

function getStudent(tx) {
	$('#busy').show();
	var sql = "select * from student_detail where id=:id";
	tx.executeSql(sql, [id], getStudent_success);
}

function getStudent_success(tx, results) {
	$('#busy').hide();
	var student = results.rows.item(0);
	$('#studentPic').attr('src', 'pics/student1.jpg');
	$('#fullName').text(student.NAME);
	$('#department').text(student.DEPARTMENT);
	$('#city').text("Chennai");

	
	
		$('#actionList').append('<li><a href="mailto:'+student.NAME+'@test.com"><p class="line1">Email</p>' +
				'<p class="line2">'+student.NAME+'@test.com</p><img src="img/mail.png" class="action-icon"/></a></li>');
	
	
	
	
		$('#actionList').append('<li><a href="tel:09988776655"><p class="line1">Call Parent</p>' +
				'<p class="line2">09988776655</p><img src="img/phone.png" class="action-icon"/></a></li>');
		$('#actionList').append('<li><a href="sms:09988776655"><p class="line1">SMS Parent</p>' +
				'<p class="line2">09988776655</p><img src="img/sms.png" class="action-icon"/></a></li>');
	
	setTimeout(function(){
		scroll.refresh();
	});
	db = null;
}

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}
