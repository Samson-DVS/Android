var db;
var dbCreated = false;


 // onDeviceReady();
document.addEventListener("deviceready", onDeviceReady, false);
//document.addEventListener("deviceready", alert(123), false);

function onDeviceReady() {
 document.addEventListener("backbutton", function(){}, false);
 //window.addEventListener("orientationchange", function(){
  // window.screen.lockOrientation('portrait-primary');
  // });
    db = window.openDatabase("StudentDirectoryDB", "1.0", "test", 200000);
   	db.transaction(populateDB, transaction_error, populateDB_success);


	
	}

function transaction_error(tx, error) {
	$('#busy').hide();
    alert("Database Error: " + error);
}

function populateDB_success() {
	dbCreated = true;
//    db.transaction(getEmployees, transaction_error);
}

function populateDB(tx) {
	$('#busy').show();

	var sql = 
		"CREATE TABLE IF NOT EXISTS student_detail ( "+
		"id INTEGER PRIMARY KEY AUTOINCREMENT, " +
		"NAME VARCHAR(50), " +
		"REGNO INTEGER, " + 
		"DEPARTMENT VARCHAR(50), " +
		"YEAR VARCHAR(50))";
    tx.executeSql(sql);

	 sql = "select id from student_detail";
 tx.executeSql(sql, [], checkstudent);

	sql = 
		"CREATE TABLE IF NOT EXISTS login ( "+
		"id INTEGER PRIMARY KEY AUTOINCREMENT, " +
		"username VARCHAR(50), " +
		"usertype INTEGER, " + 
		"password VARCHAR(50), " +
		"regno INTEGER)";
    tx.executeSql(sql);
	sql = "select id from login";
	tx.executeSql(sql, [], checklogin);	
	sql = 
		"CREATE TABLE IF NOT EXISTS attendance ( "+
		"id INTEGER PRIMARY KEY AUTOINCREMENT, " +
		"status VARCHAR(50), " +
		"intime VARCHAR(50), " + 
		"outtime VARCHAR(50), " +
		"attdate DATETIME, " +
		"regno INTEGER)";
    tx.executeSql(sql);
	sql = "select id from attendance";
	tx.executeSql(sql, [], checkAtt);


sql = 
		"CREATE TABLE IF NOT EXISTS marklist ( "+
		"id INTEGER PRIMARY KEY AUTOINCREMENT, " +
		"regno INTEGER, " +
		"semester1 INTEGER, " + 
		"semester2 INTEGER, " +
		"semester3 INTEGER, " +
		"semester4 INTEGER,semester5 INTEGER,semester6 INTEGER,semester7 INTEGER,semester8 INTEGER)";
    tx.executeSql(sql);
	sql = "select id from marklist";
	tx.executeSql(sql, [], checkMark);	
}

function checkstudent(tx, results)
{
var len = results.rows.length;

if(len==0)
{
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Arun','1121','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Aravind','1122','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Rajkumar','1123','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Karthik','1124','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Vignesh','1125','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Krishna','1126','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Arul','1127','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Ranjith','1128','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Jeeva','1129','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Maran','1130','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Bala','1131','INFORMATION TECHNOLOGY','2')");
tx.executeSql("INSERT INTO student_detail (NAME,REGNO,DEPARTMENT,YEAR) VALUES ('Gowtham','1132','INFORMATION TECHNOLOGY','2')");


}
}

function checklogin(tx, results)
{
var len = results.rows.length;
if(len==0)
{
tx.executeSql("INSERT INTO login (username,password,usertype,regno) VALUES ('Rajesh','raj@123',1,0)");
tx.executeSql("INSERT INTO login (username,password,usertype,regno) VALUES ('Ramkumar','ram@123',1,0)");
tx.executeSql("INSERT INTO login (username,password,usertype,regno) VALUES ('1121','1121@123',2,1121)");
tx.executeSql("INSERT INTO login (username,password,usertype,regno) VALUES ('1122','1122@123',2,1122)");
tx.executeSql("INSERT INTO login (username,password,usertype,regno) VALUES ('1123','1123@123',2,1123)");
tx.executeSql("INSERT INTO login (username,password,usertype,regno) VALUES ('1124','1124@123',2,1124)");
tx.executeSql("INSERT INTO login (username,password,usertype,regno) VALUES ('1125','1125@123',2,1125)");
tx.executeSql("INSERT INTO login (username,password,usertype,regno) VALUES ('1126','1126@123',2,1126)");
tx.executeSql("INSERT INTO login (username,password,usertype,regno) VALUES ('1127','1127@123',2,1127)");
}
}
function checkMark(tx, results)
{
var len = results.rows.length;
if(len==0)
{
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1121','98','92','96')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1122','98','92','96')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1123','93','92','96')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1124','88','72','86')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1125','98','93','96')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1126','98','92','96')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1127','67','78','86')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1128','78','72','76')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1129','98','92','96')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1130','88','82','70')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1131','78','82','76')");
tx.executeSql("INSERT INTO marklist (regno,semester1,semester2,semester3) VALUES ('1132','98','92','96')");


}
}
function checkAtt(tx, results)
{
var len = results.rows.length;

if(len==0)
{
	var de=new Date();
	var dt;
de.setDate(de.getDate()-1);
dt=de.getDate()+"-"+(de.getMonth()+1)+"-"+de.getFullYear();
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1121','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1122','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1123','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1124','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1125','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1126','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1127','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1128','absent','','','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1129','absent','','','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1130','absent','','','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1131','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1132','Present','09:00','17:30','"+dt+"')");

de.setDate(de.getDate()-1);
dt=de.getDate()+"-"+(de.getMonth()+1)+"-"+de.getFullYear();
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1121','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1122','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1123','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1124','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1125','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1126','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1127','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1128','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1129','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1130','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1131','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1132','Present','09:00','17:30','"+dt+"')");

de.setDate(de.getDate()-1);
dt=de.getDate()+"-"+(de.getMonth()+1)+"-"+de.getFullYear();
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1121','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1122','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1123','absent','','','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1124','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1125','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1126','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1127','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1128','absent','','','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1129','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1130','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1131','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1132','Present','09:00','17:30','"+dt+"')");

de.setDate(de.getDate()-1);
dt=de.getDate()+"-"+(de.getMonth()+1)+"-"+de.getFullYear();
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1121','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1122','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1123','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1124','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1125','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1126','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1127','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1128','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1129','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1130','Present','09:00','17:30','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1131','absent','','','"+dt+"')");
tx.executeSql("INSERT INTO attendance (regno,status,intime,outtime,attdate) VALUES ('1132','Present','09:00','17:30','"+dt+"')");

}
}

function login()
{
	db.transaction(function(tx){validate_login(tx,document.getElementById("username").value,document.getElementById("password").value);}, transaction_error);
	
}

function validate_login(txn,uname,pwd)
{
	sql="select * from login where username='"+uname+"' and password='"+pwd+"'";
	txn.executeSql(sql, [], loginresult);
}

function loginresult(tx,results)
{
	var len = results.rows.length;
	if(len==0)
	{
		alert("Login failed");
	}
	else
	{
		var user=results.rows.item(0);
		
		if(user.usertype==1)
		{
			window.location="staffmenu.html";
		}
		else
		{
			window.location="studentmenu.html?regno="+user.regno;
			
		}		
		
		
	}	
	
}
