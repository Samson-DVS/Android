
var scroll = new iScroll('wrapper', { vScrollbar: false, hScrollbar:false, hScroll: false });
// onDeviceReady();
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
		  document.addEventListener("backbutton", function(){}, false);
}
