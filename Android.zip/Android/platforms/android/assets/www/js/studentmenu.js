var regno=getUrlVars()["regno"];
var scroll = new iScroll('wrapper', { vScrollbar: false, hScrollbar:false, hScroll: false });
// onDeviceReady();
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
				 document.addEventListener("backbutton", function(){}, false);
// window.addEventListener("orientationchange", function(){
  // window.screen.lockOrientation('portrait-primary');
  // });
var menu=''+
		'<li><a href="s_attsum.html?regno='+regno+'"><img src="pics/att_m.jpg" class="list-icon"/><p class="line1">Attendance Summary</p><p class="line2">View my attendance</p></a></li>'+
		'<li><a href="s_marklist.html?regno='+regno+'"><img src="pics/result.png" class="list-icon"/><p class="line1">Student Mark list</p><p class="line2">View Semester Mark details</p></a></li>'+
		'<li><a href="index.html?regno='+regno+'"><img src="pics/logout.png" class="list-icon"/><p class="line1">Logout</p><p class="line2"></p></a></li>'+
		'';
document.getElementById("wrap1").innerHTML=menu;
}
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}