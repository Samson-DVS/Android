var db;
var dbCreated = false;
var name=[];
var scroll = new iScroll('wrapper', { vScrollbar: true, hScrollbar:true, hScroll: true, disableMouse: false,  disablePointer: false });
var s_regno=getUrlVars()["regno"];
// onDeviceReady();
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
				 document.addEventListener("backbutton", function(){}, false);
  
     db = window.openDatabase("StudentDirectoryDB", "1.0", "test", 200000);
	// db.transaction(getStudentNames, transaction_error);
    db.transaction(getStudents, transaction_error);
	
document.getElementById("backnav_a").href="studentmenu.html?regno="+s_regno;
	
}

function transaction_error(tx, error) {
	//$('#busy').hide();
    alert("Database Error: " + error);
}

function getStudents(tx) {
	var display_date=[];
	
	var today = new Date();

	//var sql = "select s.NAME NAME,s.REGNO REGNO,a.attdate attdate,a.status status " + 
			//	"from attendance a ,student_detail s where a.regno=s.REGNO and a.attdate like '%"+(today.getMonth()+1)+"-"+today.getFullYear()+"'";
	//var sql = "select regno , status, count(1) cnt from attendance where attdate like '%"+(today.getMonth()+1)+"-"+today.getFullYear()+"' group by regno,status";
	var sql="select s.Name,m.* from marklist m join student_detail s on s.REGNO=m.regno where s.REGNO="+s_regno+"";
	
	tx.executeSql(sql, [], getStudents_success);
}

function getStudents_success(tx, results) {

    var len = results.rows.length;
var tabledata="<table cellspacing=.1 width=100% ><tr style='background-color:Grey;'><td style='color:white'>Name</td><td style='color:white'>RegNo</td><td style='color:white'>Sem1</td><td style='color:white'>Sem2</td><td style='color:white'>Sem3</td><td style='color:white'></td><td style='color:white'></td><td style='color:white'></td><td style='color:white'></td><td style='color:white'></td></tr>";
 for (var i=0; i<len; i++) {
    	var student = results.rows.item(i);
		var nam=results.rows.item(i).NAME;
		var reg=results.rows.item(i).regno;
		var colr;
		if(reg%2==0)
		{
		colr="#ebebe0";	
		}
		else
		{
		colr="#f5f5f0";	
		}
	
		
	tabledata+="<tr style='background-color:"+colr+"'><td>"+nam+"</td><td>"+reg+"</td><td>"+results.rows.item(i).semester1+"%</td><td>"+results.rows.item(i).semester2+"%</td><td>"+results.rows.item(i).semester3+"%</td><td></td><td></td><td></td><td></td><td></td></tr>";		
	//tabledata+="<tr style=''><td>"+results.rows.item(i).NAME+"</td><td>"+results.rows.item(i).REGNO+"</td><td>"+results.rows.item(i).status+"</td><td>"+results.rows.item(i).attdate+"</td></tr>";	

		
		
    }
	tabledata+="</table>";
	document.getElementById("studentlist").innerHTML=tabledata;
	setTimeout(function(){
		scroll.refresh();
	},100);
	//db = null;
}

function getStudentNames(tx) {
	var display_date=[];
	
	var today = new Date();

	//var sql = "select s.NAME NAME,s.REGNO REGNO,a.attdate attdate,a.status status " + 
	//			"from attendance a ,studentdetail s where a.regno=s.REGNO and a.attdate like '%"+(today.getMonth()+1)+"-"+today.getFullYear()+"'";
	var sql = "select NAME,REGNO from student_detail";
	tx.executeSql(sql, [], getStudentName);
}

function getStudentName(tx, results) {

    var len = results.rows.length;
	for (var i=0; i<len; i++) {
	var student = results.rows.item(i);
	alert(student.NAME);
	name[(student.REGNO)]=student.NAME;
	alert(name[student.REGNO]);
	}
	alert(len);
}

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

	
