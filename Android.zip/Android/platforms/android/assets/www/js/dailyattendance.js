var db;
var dbCreated = false;

//var scroll = new iScroll('wrapper', { vScrollbar: false, hScrollbar:false, hScroll: false, disableMouse: false,  disablePointer: false });
// onDeviceReady();
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
	
 document.addEventListener("backbutton", function(){}, false);
  
     db = window.openDatabase("StudentDirectoryDB", "1.0", "test", 200000);
    db.transaction(getStudents, transaction_error);
	
	var today = new Date();
document.getElementById('present_date').innerHTML = ':   '+today.getDate()+'/'+(today.getMonth()+1)+'/'+today.getFullYear();
	
}

function transaction_error(tx, error) {
	//$('#busy').hide();
    alert("Database Error: " + error);
}

function getStudents(tx) {
	var sql = "select * " + 
				"from student_detail order by NAME";
	tx.executeSql(sql, [], getStudents_success);
}

function getStudents_success(tx, results) {

    var len = results.rows.length;
 for (var i=0; i<len; i++) {
    	var student = results.rows.item(i);
		$('#studentlist').append('<li><a href="#' + student.id + '">' +
				'<p class="line1">' + student.NAME + ' (Reg No:' + student.REGNO + ') &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u onclick=updateatt('+student.REGNO+')>Update</u></p>' +
				'<p class="line2">'+
				'select attendance:<select name=att_status_'+student.REGNO+' id=att_status_'+student.REGNO+'><option></option><option>Present</option><option>absent</option></select>'+
				'<br>In-time:<select id=ih_'+student.REGNO+'><option>hh</option><option>09</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option></select>:'+
				'<select id=im_'+student.REGNO+'><option>mm</option><option>00</option><option>05</option><option>10</option><option>15</option><option>20</option><option>25</option><option>30</option><option>35</option><option>40</option><option>45</option><option>50</option><option>55</option></select>'+
				'|Out-time:<select id=oh_'+student.REGNO+'><option>hh</option><option>09</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option></select>:'+
				'<select id=om_'+student.REGNO+'><option>mm</option><option>00</option><option>05</option><option>10</option><option>15</option><option>20</option><option>25</option><option>30</option><option>35</option><option>40</option><option>45</option><option>50</option><option>55</option></select>'+			
				'</p>' +
				'</a></li>');
		var de=new Date();
		//de.setDate(de.getDate() -2);
		var sq="select * from attendance where regno="+student.REGNO+" and attdate='"+de.getDate()+"-"+(de.getMonth()+1)+"-"+de.getFullYear()+"'";
		
		//tx.executeSql(sq,[],gs);
		tx.executeSql(sq,[],function(tx,r){
			
			var len = r.rows.length;
			if(len!=0)
			{
				
				document.getElementById('att_status_'+r.rows.item(0).regno).value=r.rows.item(0).status;
				
				var ita=r.rows.item(0).intime.split(":");
				var ota=r.rows.item(0).outtime.split(":");
				if(ita.length!=0)
				{
				document.getElementById('ih_'+r.rows.item(0).regno).value=ita[0];
				document.getElementById('im_'+r.rows.item(0).regno).value=ita[1];
				}
				if(ota.length!=0)
				{
				document.getElementById('oh_'+r.rows.item(0).regno).value=ota[0];
				document.getElementById('om_'+r.rows.item(0).regno).value=ota[1];
				}
			}
			});
		
		
		
		// $('#studentlist').append('<li><a href="#' + student.id + '">' +
				// '<p class="line1">' + student.NAME + ' (Reg No:' + student.REGNO + ')</p>' +
				// '<p class="line2">'+
				// 'select attendance:<select name=att_status onchange="alert('+student.REGNO+'+this.value)"><option></option><option>Present</option><option>Absent</option></select>'+
				// '<br>In-time:<select><option>hh</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option></select>:'+
				// '<select><option>mm</option><option>00</option><option>05</option><option>10</option><option>15</option><option>20</option><option>25</option><option>30</option><option>35</option><option>40</option><option>45</option><option>50</option><option>55</option></select>'+
				// '|Out-time:<select><option>hh</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option></select>:'+
				// '<select><option>mm</option><option>00</option><option>05</option><option>10</option><option>15</option><option>20</option><option>25</option><option>30</option><option>35</option><option>40</option><option>45</option><option>50</option><option>55</option></select>'+			
				// '</p>' +
				// '</a></li>');
    }
	// setTimeout(function(){
		//scroll.refresh();
	// },100);
	//db = null;
}

function updateatt(regno)
{
	var statuss=document.getElementById('att_status_'+regno).value;
	var intime=document.getElementById('ih_'+regno).value+":"+document.getElementById('im_'+regno).value;	
	var outtime=document.getElementById('oh_'+regno).value+":"+document.getElementById('om_'+regno).value;
			intime=intime.replace("hh","").replace("mm","")	;
			outtime=outtime.replace("hh","").replace("mm","");
	if(intime.trim().length==1)
	{
		intime="";
	}
	if(outtime.trim().length==1)
	{
		outtime="";
	}
	var de=new Date();
	var da=de.getDate()+"-"+(de.getMonth()+1)+"-"+de.getFullYear();
	db.transaction(function(tx){tx.executeSql("delete from attendance where regno="+regno+" and attdate='"+da+"'")},transaction_error);
	db.transaction(function(tx){tx.executeSql("insert into  attendance (regno,attdate,status,intime,outtime) values ('"+regno+"','"+da+"','"+statuss+"','"+intime+"','"+outtime+"') ");}, transaction_error,alert("Updated"));
}



	
