var db;
var dbCreated = false;
var name=[];
var scroll = new iScroll('wrapper', { vScrollbar: false, hScrollbar:false, hScroll: false, disableMouse: false,  disablePointer: false });
var s_regno=getUrlVars()["regno"];
// onDeviceReady();
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {
				 document.addEventListener("backbutton", function(){}, false);
  
     db = window.openDatabase("StudentDirectoryDB", "1.0", "test", 200000);
	// db.transaction(getStudentNames, transaction_error);
    db.transaction(getStudents, transaction_error);
	
	var months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
	var today = new Date();
document.getElementById('present_date').innerHTML = ':'+months[today.getMonth()]+'-'+today.getFullYear();
document.getElementById("backnav_a").href="studentmenu.html?regno="+s_regno;	
}

function transaction_error(tx, error) {
	//$('#busy').hide();
    alert("Database Error: " + error);
}

function getStudents(tx) {
	var display_date=[];
	
	var today = new Date();

	var sql = "select s.NAME NAME,s.REGNO REGNO,a.attdate attdate,upper(a.status) status,a.intime,a.outtime " + 
				"from attendance a ,student_detail s where a.regno=s.REGNO and a.attdate like '%"+(today.getMonth()+1)+"-"+today.getFullYear()+"' and s.REGNO="+s_regno;
	//var sql = "select regno , status, count(1) cnt from attendance where attdate like '%"+(today.getMonth()+1)+"-"+today.getFullYear()+"' group by regno,status";
	//var sql="select s.NAME NAME,s.REGNO,upper(a.status) status,a.cnt from student_detail s join (select regno , status, count(1) cnt from attendance where attdate like '%"+(today.getMonth()+1)+"-"+today.getFullYear()+"' group by regno,status) as a on a.regno=s.REGNO where s.REGNO="+s_regno+"";
	
	tx.executeSql(sql, [], getStudents_success);
}

function getStudents_success(tx, results) {
var prename="";
var prereg="";
    var len = results.rows.length;
var tabledata="<table cellspacing=0 width=100% ><tr style='background-color:Grey;'><td style='color:white'>Name</td><td style='color:white'>RegNo</td><td style='color:white'>Date</td><td style='color:white'>Status</td><td style='color:white'>In</td><td style='color:white'>Out</td></tr>";
 for (var i=0; i<len; i++) {
    	var student = results.rows.item(i);
		var nam=results.rows.item(i).NAME;
		var reg=results.rows.item(i).REGNO;
		var colr;
		if(reg%2==0)
		{
		colr="#ebebe0";	
		}
		else
		{
		colr="#f5f5f0";	
		}
		if(prename==nam){nam="";}
		if(prereg==reg){reg="";}
		
	tabledata+="<tr style='background-color:"+colr+"'><td>"+nam+"</td><td>"+reg+"</td><td>"+results.rows.item(i).attdate+"</td><td>"+results.rows.item(i).status+"</td><td>"+results.rows.item(i).intime+"</td><td>"+results.rows.item(i).outtime+""+"</td></tr>";		
	//tabledata+="<tr style=''><td>"+results.rows.item(i).NAME+"</td><td>"+results.rows.item(i).REGNO+"</td><td>"+results.rows.item(i).status+"</td><td>"+results.rows.item(i).attdate+"</td></tr>";	
		prename=results.rows.item(i).NAME;
		prereg=results.rows.item(i).REGNO;
		
		
    }
	tabledata+="</table>";
	document.getElementById("studentlist").innerHTML=tabledata;
	setTimeout(function(){
		scroll.refresh();
	},100);
	//db = null;
}

function getStudentNames(tx) {
	var display_date=[];
	
	var today = new Date();

	//var sql = "select s.NAME NAME,s.REGNO REGNO,a.attdate attdate,a.status status " + 
	//			"from attendance a ,studentdetail s where a.regno=s.REGNO and a.attdate like '%"+(today.getMonth()+1)+"-"+today.getFullYear()+"'";
	var sql = "select NAME,REGNO from student_detail";
	tx.executeSql(sql, [], getStudentName);
}

function getStudentName(tx, results) {

    var len = results.rows.length;
	for (var i=0; i<len; i++) {
	var student = results.rows.item(i);
	alert(student.NAME);
	name[(student.REGNO)]=student.NAME;
	alert(name[student.REGNO]);
	}
	alert(len);
}
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}


	
